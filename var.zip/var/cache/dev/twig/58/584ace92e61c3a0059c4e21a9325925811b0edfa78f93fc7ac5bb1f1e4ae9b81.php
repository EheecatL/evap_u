<?php

/* @App/pages/extendsarticles.html.twig */
class __TwigTemplate_d689a74e3dd6d4fb3a00b09532d19d71775b3d828298792b0f0078db3ce65b0e extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("@App/base/index.html.twig", "@App/pages/extendsarticles.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@App/base/index.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/pages/extendsarticles.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/pages/extendsarticles.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "
    Articles

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 10
        echo "
    <div class=\"container-fluid mb-5\">
        <div class=\"row\">
            <div class=\"col-3 text-center titres\">Articles</div>
        </div>
    </div>

    ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["articles"]) || array_key_exists("articles", $context) ? $context["articles"] : (function () { throw new Twig_Error_Runtime('Variable "articles" does not exist.', 17, $this->source); })()));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["article"]) {
            // line 18
            echo "
        ";
            // line 19
            if ((twig_get_attribute($this->env, $this->source, $context["loop"], "index", array()) % 2 == 1)) {
                // line 20
                echo "
            <div class=\"container-fluid bgcg pt-5 pb-5  \">

        ";
            }
            // line 24
            echo "
        ";
            // line 25
            if ((twig_get_attribute($this->env, $this->source, $context["loop"], "index", array()) % 2 == 0)) {
                // line 26
                echo "
            <div class=\"container-fluid pt-5 pb-5\">

        ";
            }
            // line 30
            echo "
                <div class=\"container mb-5\">
                    <div class=\"row\">
                        <div class=\"col-4\">
                            <img src=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("uploads/img/" . twig_get_attribute($this->env, $this->source, $context["article"], "image", array()))), "html", null, true);
            echo "\" class=\"img-fluid\">
                        </div>
                        <div class=\"col-8 align-self-center\">
                            <h4 class=\"d-flex align-self-center\">";
            // line 37
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["article"], "title", array()), "html", null, true);
            echo "</h4>
                            <p><em>";
            // line 38
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["article"], "releasedate", array()), "d/m/y"), "html", null, true);
            echo "</em> -
                                <a href=\"";
            // line 39
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("info_article", array("id" => twig_get_attribute($this->env, $this->source, $context["article"], "id", array()))), "html", null, true);
            echo "\">
                                                <span class=\"read\">
                                                    <strong>
                                                        Lire
                                                    </strong>
                                                     </span>
                                    <i class=\"fas fa-wind\"></i>
                                </a>
                            <p class=\"artcontent\">";
            // line 47
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["article"], "content", array()), "html", null, true);
            echo "</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['article'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 56
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@App/pages/extendsarticles.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  178 => 56,  155 => 47,  144 => 39,  140 => 38,  136 => 37,  130 => 34,  124 => 30,  118 => 26,  116 => 25,  113 => 24,  107 => 20,  105 => 19,  102 => 18,  85 => 17,  76 => 10,  67 => 9,  54 => 4,  45 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@App/base/index.html.twig' %}

{% block title %}

    Articles

{% endblock %}

{% block content %}

    <div class=\"container-fluid mb-5\">
        <div class=\"row\">
            <div class=\"col-3 text-center titres\">Articles</div>
        </div>
    </div>

    {% for article in articles %}

        {% if loop.index is odd %}

            <div class=\"container-fluid bgcg pt-5 pb-5  \">

        {% endif %}

        {% if loop.index is even %}

            <div class=\"container-fluid pt-5 pb-5\">

        {% endif %}

                <div class=\"container mb-5\">
                    <div class=\"row\">
                        <div class=\"col-4\">
                            <img src=\"{{ asset('uploads/img/'~article.image) }}\" class=\"img-fluid\">
                        </div>
                        <div class=\"col-8 align-self-center\">
                            <h4 class=\"d-flex align-self-center\">{{ article.title }}</h4>
                            <p><em>{{ article.releasedate | date(\"d/m/y\")}}</em> -
                                <a href=\"{{ path('info_article', {'id': article.id}) }}\">
                                                <span class=\"read\">
                                                    <strong>
                                                        Lire
                                                    </strong>
                                                     </span>
                                    <i class=\"fas fa-wind\"></i>
                                </a>
                            <p class=\"artcontent\">{{ article.content }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    {% endfor %}

{% endblock %}


", "@App/pages/extendsarticles.html.twig", "/Applications/MAMP/htdocs/evap_u/src/AppBundle/Resources/views/pages/extendsarticles.html.twig");
    }
}
